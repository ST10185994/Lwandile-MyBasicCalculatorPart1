package com.example.mybasiccalculalatorapppart1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        addingtwonumbers()

    }

    fun addingtwonumbers() {
        val num1 = findViewById<EditText>(R.id.Number1)
        val num2 = findViewById<EditText>(R.id.Number2)
        val button1 = findViewById<Button>(R.id.addbutton)
        val subbutton = findViewById<Button>(R.id.subbutton)
        val Divbutton = findViewById<Button>(R.id.Divbutton)
        val Multbutton = findViewById<Button>(R.id.Multbutton)
        val clearbutton = findViewById<Button>(R.id.clearbutton)
        val output = findViewById<TextView>(R.id.output)
        val answer = findViewById<TextView>(R.id.answer)


        button1.setOnClickListener {
            val addnum1 = num1.text.toString().toInt()
            val addnum2 = num1.text.toString().toInt()
            val result = addnum1 + addnum2
            output.text = "$num1 + $num2 = ${addingtwonumbers()}"
        }

        subbutton.setOnClickListener {
            val addnum1 = num1.text.toString().toInt()
            val addnum2 = num1.text.toString().toInt()
            val resultsub = addnum1 - addnum2
            output.text = "$num1 + $num2 = ${addingtwonumbers()}"
        }


        Multbutton.setOnClickListener {
            val addnum1 = num1.text.toString().toInt()
            val addnum2 = num1.text.toString().toInt()
            val resultMult = addnum1 * addnum2
            Toast.makeText(this, "$resultMult", Toast.LENGTH_LONG).show()
        }


        Divbutton.setOnClickListener {
            if (num1.text.toString() == "") {
                Toast.makeText(this, "Please enter your first number!", Toast.LENGTH_LONG).show()
            } else if (num2.text.toString() == "") {
                Toast.makeText(this, "Please enter your second number!", Toast.LENGTH_LONG).show()
            } else {
                if (num2.text.toString().toInt() == 0) {
                    output.text = "Error\nSecond number can't be 0"
                } else {
                    output.text =
                        "${num1.text} / ${num2.text} = " + (num1.text.toString()
                            .toDouble() / num2.text.toString().toInt())


                    clearbutton.setOnClickListener {
                        num1.setText("");
                        num2.setText("");

                        Toast.makeText(this, "cleared", Toast.LENGTH_LONG).show()

                    }
                }

            }
        }
    }
}